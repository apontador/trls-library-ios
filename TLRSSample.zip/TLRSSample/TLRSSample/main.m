//
//  main.m
//  TLRSSample
//
//  Created by Rodrigo Placido on 20/02/15.
//  Copyright (c) 2015 Apontador. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
